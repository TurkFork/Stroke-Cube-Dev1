/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class NormalText extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./NormalText/costumes/costume1.svg", {
        x: 167.85149388083872,
        y: 33.60872391244325
      })
    ];

    this.sounds = [new Sound("pop", "./NormalText/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Normal" },
        this.whenIReceiveNormal
      ),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay2),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Normal" },
        this.whenIReceiveNormal2
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenIReceivePlay() {
    this.visible = true;
  }

  *whenIReceiveNormal() {
    this.visible = false;
  }

  *whenIReceivePlay2() {
    this.visible = true;
  }

  *whenIReceiveMenu2() {
    this.visible = false;
  }

  *whenGreenFlagClicked() {
    while (true) {
      yield* this.wait(0.5);
      yield* this.sizeChange2();
      yield* this.wait(0.5);
      yield* this.sizeChange();
      yield;
    }
  }

  *sizeChange() {
    for (let i = 0; i < 10; i++) {
      this.size += 2;
      yield;
    }
  }

  *sizeChange2() {
    for (let i = 0; i < 10; i++) {
      this.size -= 2;
      yield;
    }
  }

  *whenIReceivePlay3() {
    this.visible = true;
  }

  *whenIReceiveNormal2() {
    this.visible = false;
  }

  *whenIReceiveMenu3() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    this.visible = false;
  }

  *whenGreenFlagClicked3() {
    this.size = 100;
  }
}
