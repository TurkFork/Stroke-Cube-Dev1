/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Button6 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("mods on", "./Button6/costumes/mods on.svg", {
        x: 44.83099999999999,
        y: 31.180000000000007
      }),
      new Costume("spanish", "./Button6/costumes/spanish.svg", {
        x: 44.83100000000002,
        y: 31.180000000000007
      }),
      new Costume("mods off", "./Button6/costumes/mods off.svg", {
        x: 45.50050000000002,
        y: 27.335999999999984
      }),
      new Costume("button3-b", "./Button6/costumes/button3-b.svg", {
        x: 72,
        y: 72
      }),
      new Costume("puzzle-piece", "./Button6/costumes/puzzle-piece.svg", {
        x: 19,
        y: 19
      })
    ];

    this.sounds = [
      new Sound("pop", "./Button6/sounds/pop.wav"),
      new Sound(
        "808-cowbell_G_minor",
        "./Button6/sounds/808-cowbell_G_minor.wav"
      ),
      new Sound(
        "phonk-house-cowbell_150bpm_C_major",
        "./Button6/sounds/phonk-house-cowbell_150bpm_C_major.wav"
      ),
      new Sound(
        "windows-10-error-sound-By-Tuna",
        "./Button6/sounds/windows-10-error-sound-By-Tuna.mp3"
      ),
      new Sound(
        "fatal-error-By-Tuna",
        "./Button6/sounds/fatal-error-By-Tuna.wav"
      )
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "versoins" },
        this.whenIReceiveVersoins
      ),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenIReceiveMenu() {
    if (this.toString(this.stage.vars.mods) === "on") {
      this.costume = "mods on";
    } else {
      this.costume = "mods off";
    }
  }

  *whenIReceivePlay() {
    this.visible = false;
  }

  *whenIReceiveSettings() {
    this.visible = false;
  }

  *whenIReceiveVersoins() {
    this.visible = false;
  }

  *whenIReceivePlay2() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    this.visible = true;
  }

  *whenIReceiveMenu2() {
    this.visible = true;
  }

  *whenthisspriteclicked() {
    if (this.costume.name === "mods on") {
      this.broadcast("mods menu");
    } else {
      this.broadcast("mods off");
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.stage.vars.mods) === "on") {
        this.costume = "mods on";
      } else {
        this.costume = "mods off";
      }
      if (this.toString(this.stage.vars.theme) === "minimal") {
        this.costume = "puzzle-piece";
      } else {
        0;
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.theme) === "on") {
        this.costume = "mods on";
      } else {
        if (null) {
          null;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked5() {
    while (true) {
      if (this.toString(this.stage.vars.theme) === "minimal") {
        0;
      } else {
        null;
      }
      yield;
    }
  }
}
