/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Theme extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("theme=defualt", "./Theme/costumes/theme=defualt.svg", {
        x: 72.91252506811446,
        y: 19.936353179798516
      }),
      new Costume("theme=the-cube", "./Theme/costumes/theme=the-cube.svg", {
        x: 75.09731955624338,
        y: 20.47372722051327
      }),
      new Costume("theme=retro", "./Theme/costumes/theme=retro.svg", {
        x: 75.09731955624338,
        y: 20.47372722051327
      }),
      new Costume("EXAMPLE", "./Theme/costumes/EXAMPLE.svg", {
        x: 75.09732186917691,
        y: 20.47373361025666
      }),
      new Costume("EXAMPLE2", "./Theme/costumes/EXAMPLE2.svg", {
        x: 75.09731955624338,
        y: 20.47372722051327
      })
    ];

    this.sounds = [
      new Sound("pop", "./Theme/sounds/pop.wav"),
      new Sound("Dance Celebrate", "./Theme/sounds/Dance Celebrate.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked6)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.theme = "light";
  }

  *whenIReceiveSettings() {
    this.visible = true;
  }

  *whenGreenFlagClicked3() {
    this.moveAhead();
  }

  *whenthisspriteclicked() {
    yield* this.askAndWait("Set theme to?");
    if (this.answer === "light") {
      this.stage.vars.theme = "light";
    }
    if (this.answer === "dark") {
      this.stage.vars.theme = "dark";
    }
    if (this.answer === "the cube") {
      this.stage.vars.theme = "the cube";
    }
    if (this.answer === "minimal") {
      this.stage.vars.theme = "minimal";
    }
    if (this.answer === "car battery") {
      this.stage.vars.theme = "car battery";
    }
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenIReceiveSettings2() {
    this.visible = true;
  }

  *whenGreenFlagClicked4() {
    this.costume = "theme=defualt";
  }

  *whenGreenFlagClicked5() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenGreenFlagClicked6() {
    while (true) {
      if (this.toString(this.stage.vars.theme) === "the cube") {
        this.costume = "theme=the-cube";
      }
      if (
        this.toString(this.stage.vars.theme) === "light" ||
        this.toString(this.stage.vars.theme) === "dark"
      ) {
        this.costume = "theme=defualt";
      }
      yield;
    }
  }
}
