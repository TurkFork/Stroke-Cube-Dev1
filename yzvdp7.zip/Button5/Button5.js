/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Button5 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("button3-a", "./Button5/costumes/button3-a.svg", {
        x: 44.83099999999999,
        y: 31.180000000000007
      }),
      new Costume("spanish", "./Button5/costumes/spanish.svg", {
        x: 44.831000000000046,
        y: 31.180000000000007
      }),
      new Costume("button3-b", "./Button5/costumes/button3-b.svg", {
        x: 72,
        y: 72
      }),
      new Costume("settings", "./Button5/costumes/settings.svg", {
        x: 166.382815,
        y: 91.5
      })
    ];

    this.sounds = [new Sound("pop", "./Button5/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "versoins" },
        this.whenIReceiveVersoins
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = true;
  }

  *whenIReceiveVersoins() {
    this.visible = false;
  }

  *whenIReceiveMenu() {}

  *whenIReceivePlay() {
    this.visible = false;
  }

  *whenthisspriteclicked() {
    this.broadcast("settings");
  }

  *whenIReceiveMenu2() {
    this.visible = true;
  }

  *setSizeToMouseHover() {
    while (!(this.size === 130)) {
      this.size += 10;
      yield;
    }
  }

  *setSizeToNotMouseHover() {
    while (!(this.size === 100)) {
      this.size -= 5;
      yield;
    }
  }

  *setSizeToMouseHover2() {
    while (!(this.size === 130)) {
      this.size += 5;
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        if (this.toString(this.stage.vars.theme) === "dark") {
          this.costume = "dark";
        } else {
          if (this.toString(this.stage.vars.theme) === "light") {
            this.costume = "light";
          }
        }
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "Cubo de trazo dos";
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        this.costume = "button3-a";
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "spanish";
        } else {
          0;
        }
      }
      if (this.toString(this.stage.vars.theme) === "minimal") {
        this.costume = "settings";
      } else {
        null;
      }
      yield;
    }
  }

  *whenGreenFlagClicked5() {
    while (true) {
      if (this.toString(this.stage.vars.theme) === "minimal") {
        this.goto(102, -142);
      } else {
        this.goto(-142, -13);
      }
      yield;
    }
  }
}
