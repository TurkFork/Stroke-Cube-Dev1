/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite4 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite4/costumes/costume1.svg", {
        x: 0,
        y: 0
      }),
      new Costume(
        "admin_panel_settings_FILL0_wght400_GRAD0_opsz48",
        "./Sprite4/costumes/admin_panel_settings_FILL0_wght400_GRAD0_opsz48.svg",
        { x: 0, y: 0 }
      ),
      new Costume(
        "switch_account_FILL0_wght400_GRAD0_opsz48",
        "./Sprite4/costumes/switch_account_FILL0_wght400_GRAD0_opsz48.svg",
        { x: 37.35714285714286, y: 30.285714285714306 }
      ),
      new Costume("delete-user", "./Sprite4/costumes/delete-user.png", {
        x: 256,
        y: 256
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite4/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "acc menu" },
        this.whenIReceiveAccMenu
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveAccMenu() {
    this.moveAhead();
    this.visible = true;
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.account = "";
    yield* this.wait(1);
    if (/* no username */ "" === "turkforkyt") {
      this.broadcast("acc loading");
      this.stage.vars.account = "AW 👑💎 (DEV)";
    }
  }

  *whenthisspriteclicked() {
    yield* this.askAndWait("Sign In");
    if (this.answer === "AW") {
      this.stage.vars.account = "AW 👑💎 (DEV)";
    }
    if (this.answer === "Team A") {
      this.stage.vars.account = "DEV TEAM A 💎";
    }
  }
}
