/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Button4 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("button3-a", "./Button4/costumes/button3-a.svg", {
        x: 44.83099999999999,
        y: 31.180000000000007
      }),
      new Costume("spanish", "./Button4/costumes/spanish.svg", {
        x: 44.831000000000046,
        y: 31.180000000000007
      }),
      new Costume("button3-b", "./Button4/costumes/button3-b.svg", {
        x: 72,
        y: 72
      }),
      new Costume(
        "angle-small-right",
        "./Button4/costumes/angle-small-right.png",
        { x: 256, y: 256 }
      )
    ];

    this.sounds = [new Sound("pop", "./Button4/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "versoins" },
        this.whenIReceiveVersoins
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(
        Trigger.BROADCAST,
        { name: "acc menu" },
        this.whenIReceiveAccMenu
      )
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveVersoins() {
    this.visible = true;
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenthisspriteclicked() {
    this.broadcast("menu");
  }

  *whenIReceiveSettings() {
    this.visible = true;
  }

  *whenGreenFlagClicked2() {
    this.moveAhead();
  }

  *whenIReceivePlay() {
    this.visible = true;
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        if (this.toString(this.stage.vars.theme) === "dark") {
          this.costume = "dark";
        } else {
          if (this.toString(this.stage.vars.theme) === "light") {
            this.costume = "light";
          }
        }
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "Cubo de trazo dos";
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked5() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        this.costume = "button3-a";
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "spanish";
        }
      }
      yield;
    }
  }

  *whenIReceiveAccMenu() {
    this.visible = true;
  }
}
