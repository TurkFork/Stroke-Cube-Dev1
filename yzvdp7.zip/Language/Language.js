/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Language extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("language", "./Language/costumes/language.svg", {
        x: 67.34976000000003,
        y: 33.67488
      }),
      new Costume("spanish", "./Language/costumes/spanish.svg", {
        x: 67.3464795758,
        y: 34.03386036814257
      })
    ];

    this.sounds = [
      new Sound("pop", "./Language/sounds/pop.wav"),
      new Sound("error-By-Tuna", "./Language/sounds/error-By-Tuna.mp3")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];
  }

  *whenGreenFlagClicked() {
    this.moveAhead();
    this.visible = false;
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenIReceiveSettings() {
    this.visible = true;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.toString(this.stage.vars.language) === "spanish") {
      yield* this.askAndWait("establecer el idioma en");
      if (this.answer === "english") {
        this.stage.vars.language = "english";
      }
      if (this.answer === "french") {
        this.stage.vars.language = "french";
      }
      if (this.answer === "chinese") {
        this.stage.vars.language = "chinese";
      }
    }
    if (this.toString(this.stage.vars.language) === "english") {
      yield* this.askAndWait("Set language to");
      if (this.answer === "spanish") {
        this.stage.vars.language = "spanish";
      }
      if (this.answer === "french") {
        this.stage.vars.language = "french";
      }
      if (this.answer === "chinese") {
        this.stage.vars.language = "chinese";
      }
    }
    if (this.toString(this.stage.vars.language) === "french") {
      yield* this.askAndWait(" définir la langue sur");
      if (this.answer === "spanish") {
        this.stage.vars.language = "spanish";
      }
      if (this.answer === "english") {
        this.stage.vars.language = "english";
      }
      if (this.answer === "chinese") {
        this.stage.vars.language = "chinese";
      }
    }
    if (this.toString(this.stage.vars.language) === "chinese") {
      yield* this.askAndWait("将语言设置为");
      if (this.answer === "spanish") {
        this.stage.vars.language = "spanish";
      }
      if (this.answer === "english") {
        this.stage.vars.language = "english";
      }
      if (this.answer === "chinese") {
        this.stage.vars.language = "chinese";
      }
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        this.costume = "language";
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "Cubo de trazo dos";
        }
      }
      yield;
    }
  }
}
