/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Normal extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("button3-a", "./Normal/costumes/button3-a.svg", {
        x: 44.83099999999999,
        y: 31.180000000000007
      }),
      new Costume("button3-b", "./Normal/costumes/button3-b.svg", {
        x: 72,
        y: 72
      })
    ];

    this.sounds = [new Sound("pop", "./Normal/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Normal" },
        this.whenIReceiveNormal
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenIReceivePlay() {
    this.visible = true;
  }

  *whenIReceiveNormal() {
    this.visible = false;
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenthisspriteclicked() {
    this.broadcast("Normal");
  }

  *whenGreenFlagClicked2() {
    this.visible = false;
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        if (this.toString(this.stage.vars.theme) === "dark") {
          this.costume = "dark";
        } else {
          if (this.toString(this.stage.vars.theme) === "light") {
            this.costume = "light";
          }
        }
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "Cubo de trazo dos";
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        this.costume = "button3-a";
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "spanish";
        }
      }
      yield;
    }
  }
}
