/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite2/costumes/costume1.svg", {
        x: 0,
        y: 0
      }),
      new Costume("costume2", "./Sprite2/costumes/costume2.svg", {
        x: 45.407805150770855,
        y: 52.49923017660271
      }),
      new Costume(
        "account_circle_FILL0_wght400_GRAD0_opsz48",
        "./Sprite2/costumes/account_circle_FILL0_wght400_GRAD0_opsz48.svg",
        { x: 28.166666666666714, y: 28.166666666666657 }
      ),
      new Costume("user", "./Sprite2/costumes/user.png", { x: 256, y: 256 })
    ];

    this.sounds = [new Sound("Meow", "./Sprite2/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(
        Trigger.BROADCAST,
        { name: "versoins" },
        this.whenIReceiveVersoins
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked)
    ];
  }

  *whenIReceiveSettings() {
    this.visible = false;
  }

  *whenIReceivePlay() {
    this.visible = false;
  }

  *whenIReceiveMenu() {
    this.visible = true;
  }

  *whenIReceiveVersoins() {
    this.visible = false;
  }

  *whenthisspriteclicked() {
    this.broadcast("acc menu");
  }
}
