/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Error extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "Mod for older version",
        "./Error/costumes/Mod for older version.svg",
        { x: 243, y: 181 }
      ),
      new Costume("Mods Off", "./Error/costumes/Mods Off.svg", {
        x: 240.75,
        y: 180.5
      }),
      new Costume("language alpha", "./Error/costumes/language alpha.svg", {
        x: 241,
        y: 181
      }),
      new Costume("game crashed", "./Error/costumes/game crashed.svg", {
        x: 242,
        y: 183
      }),
      new Costume("hax", "./Error/costumes/hax.svg", {
        x: 252.25225225225225,
        y: 252.25225225225228
      }),
      new Costume("exclamation", "./Error/costumes/exclamation.svg", {
        x: 27.4016089108911,
        y: 27.401608910891014
      }),
      new Costume("shield-check", "./Error/costumes/shield-check.svg", {
        x: 30.44809231899748,
        y: 36.42388613861385
      }),
      new Costume("ban-bug", "./Error/costumes/ban-bug.svg", {
        x: 25.176462236990716,
        y: 25.176462236990744
      })
    ];

    this.sounds = [
      new Sound(
        "windows-10-error-sound-By-Tuna",
        "./Error/sounds/windows-10-error-sound-By-Tuna.mp3"
      ),
      new Sound("error-By-Tuna", "./Error/sounds/error-By-Tuna.mp3")
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "mods off" },
        this.whenIReceiveModsOff
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "mod out of date" },
        this.whenIReceiveModOutOfDate
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "language error" },
        this.whenIReceiveLanguageError
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "mod out of date" },
        this.whenIReceiveModOutOfDate2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "mods off" },
        this.whenIReceiveModsOff2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "language error" },
        this.whenIReceiveLanguageError2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];
  }

  *whenIReceiveModsOff() {
    this.moveAhead();
    this.costume = "Mods Off";
    this.visible = true;
    this.effects.ghost = 0;
    yield* this.playSoundUntilDone("windows-10-error-sound-By-Tuna");
    yield* this.wait(1);
    for (let i = 0; i < 10; i++) {
      this.effects.ghost += 10;
      yield;
    }
    this.visible = false;
  }

  *whenGreenFlagClicked() {
    this.stage.vars.lastErrorCodeRecoreded = [];
    this.visible = false;
  }

  *whenIReceiveModOutOfDate() {
    this.moveAhead();
    this.costume = "Mod for older version";
    this.visible = true;
    this.effects.ghost = 0;
    yield* this.playSoundUntilDone("windows-10-error-sound-By-Tuna");
    yield* this.wait(1);
    for (let i = 0; i < 10; i++) {
      this.effects.ghost += 10;
      yield;
    }
    this.visible = false;
  }

  *whenIReceiveLanguageError() {
    this.moveAhead();
    this.costume = "language alpha";
    this.visible = true;
    this.effects.ghost = 0;
    yield* this.playSoundUntilDone("windows-10-error-sound-By-Tuna");
    yield* this.wait(1);
    for (let i = 0; i < 10; i++) {
      this.effects.ghost += 10;
      yield;
    }
    this.visible = false;
  }

  *mostRecentErrorCode() {
    yield* this.wait(4);
    this.stage.vars.lastErrorCodeRecoreded.push(
      this.stage.vars.mostRecentErrorCode
    );
  }

  *whenIReceiveModOutOfDate2() {
    this.stage.vars.mostRecentErrorCode = 1034;
  }

  *whenIReceiveModsOff2() {
    this.stage.vars.mostRecentErrorCode = "mods off";
  }

  *whenIReceiveLanguageError2() {
    this.stage.vars.mostRecentErrorCode = 234105;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.toNumber(this.stage.vars.mostRecentErrorCode) === 234105) {
        yield* this.wait(1);
        yield* this.mostRecentErrorCode();
      }
      if (this.toNumber(this.stage.vars.mostRecentErrorCode) === 1034) {
        yield* this.wait(1);
        yield* this.mostRecentErrorCode();
      }
      if (this.toString(this.stage.vars.mostRecentErrorCode) === "mods off") {
        yield* this.wait(1);
        yield* this.mostRecentErrorCode();
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toNumber(this.stage.vars.score) === 1.5425824784799487e28) {
        this.moveAhead();
        this.costume = "hax";
        this.visible = true;
        this.effects.ghost = 0;
        yield* this.playSoundUntilDone("windows-10-error-sound-By-Tuna");
        yield* this.wait(1);
        for (let i = 0; i < 10; i++) {
          this.effects.ghost += 10;
          yield;
        }
        this.visible = false;
      }
      yield;
    }
  }
}
