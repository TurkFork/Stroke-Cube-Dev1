/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Versions extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Versions/costumes/costume1.svg", {
        x: 67.54575,
        y: 176.3726283203089
      })
    ];

    this.sounds = [new Sound("pop", "./Versions/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "versoins" },
        this.whenIReceiveVersoins
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveVersoins() {
    this.visible = true;
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }
}
