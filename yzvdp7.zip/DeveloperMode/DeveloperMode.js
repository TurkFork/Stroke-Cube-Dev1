/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class DeveloperMode extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Debug On", "./DeveloperMode/costumes/Debug On.svg", {
        x: 71.31781277021432,
        y: 19.50037566689997
      }),
      new Costume("Debug off", "./DeveloperMode/costumes/Debug off.svg", {
        x: 74.75360020274286,
        y: 20.438758009199944
      })
    ];

    this.sounds = [
      new Sound("pop", "./DeveloperMode/sounds/pop.wav"),
      new Sound("Dance Celebrate", "./DeveloperMode/sounds/Dance Celebrate.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked6),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked7),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked8),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked9)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.theme = 0;
  }

  *whenIReceiveSettings() {
    this.visible = true;
  }

  *whenGreenFlagClicked3() {
    this.moveAhead();
  }

  *whenthisspriteclicked() {
    if (this.costume.name === "Debug off") {
      this.stage.vars.debugMode = "On";
    }
    if (this.costume.name === "Debug On") {
      this.stage.vars.debugMode = "Off";
    }
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.debugMode) === "On") {
        this.costume = "Debug On";
      } else {
        if (this.toString(this.stage.vars.debugMode) === "Off") {
          this.costume = "Debug off";
        }
      }
      yield;
    }
  }

  *whenIReceiveSettings2() {
    this.visible = true;
  }

  *whenGreenFlagClicked5() {
    this.costume = "Debug off";
  }

  *whenGreenFlagClicked6() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenGreenFlagClicked7() {
    this.stage.vars.mods = "off";
  }

  *whenGreenFlagClicked8() {
    while (true) {
      if (this.toString(this.stage.vars.debugMode) === "On") {
        this.stage.watchers.mostRecentErrorCode.visible = true;
        this.stage.watchers.lastErrorCodeRecoreded.visible = true;
      } else {
        if (this.toString(this.stage.vars.debugMode) === "Off") {
          this.stage.watchers.mostRecentErrorCode.visible = false;
          this.stage.watchers.lastErrorCodeRecoreded.visible = false;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked9() {
    this.stage.vars.debugMode = "Off";
  }
}
