/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("light", "./Stage/costumes/light.svg", { x: 0, y: 0 }),
      new Costume("dark", "./Stage/costumes/dark.svg", { x: 243, y: 183 }),
      new Costume("THE CUBE BG", "./Stage/costumes/THE CUBE BG.svg", {
        x: 386.25,
        y: 235.75
      }),
      new Costume("cherry bakk sc2", "./Stage/costumes/cherry bakk sc2.svg", {
        x: 285.9999999999999,
        y: 285.9999999999999
      }),
      new Costume("RETRO THEME", "./Stage/costumes/RETRO THEME.svg", {
        x: 215.52137646171388,
        y: 82.41469342797686
      }),
      new Costume(
        "png-transparent-battery-charger-car-automotive-battery-battery-icon-text-rectangle-automobile-repair-shop",
        "./Stage/costumes/png-transparent-battery-charger-car-automotive-battery-battery-icon-text-rectangle-automobile-repair-shop.png",
        { x: 460, y: 256 }
      ),
      new Costume("unity", "./Stage/costumes/unity.svg", {
        x: 17.200000000000017,
        y: 17.19999999999999
      }),
      new Costume("gem", "./Stage/costumes/gem.svg", {
        x: 21.12500000000003,
        y: 21.125
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];

    this.vars.autoClicksPS = 0;
    this.vars.mode = 6;
    this.vars.cubespeed = 9;
    this.vars.score = 0;
    this.vars.theme = "minimal";
    this.vars.highscore = 1;
    this.vars.mods = "off";
    this.vars.checkIfThemeIsDarkOrLight = "light";
    this.vars.mostRecentErrorCode = "mods off";
    this.vars.debugMode = "Off";
    this.vars.language = "english";
    this.vars.ads = 0;
    this.vars.account = "AW 👑💎 (DEV)";
    this.vars.lastErrorCodeRecoreded = [
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off",
      "mods off"
    ];

    this.watchers.score = new Watcher({
      label: "score",
      style: "normal",
      visible: true,
      value: () => this.vars.score,
      x: 620,
      y: 180
    });
    this.watchers.mostRecentErrorCode = new Watcher({
      label: "most recent error code",
      style: "normal",
      visible: false,
      value: () => this.vars.mostRecentErrorCode,
      x: 240,
      y: -158
    });
    this.watchers.account = new Watcher({
      label: "account",
      style: "large",
      visible: true,
      value: () => this.vars.account,
      x: 240,
      y: 180
    });
    this.watchers.lastErrorCodeRecoreded = new Watcher({
      label: "last error code recoreded",
      style: "normal",
      visible: false,
      value: () => this.vars.lastErrorCodeRecoreded,
      x: 625,
      y: 111,
      width: 100,
      height: 184
    });
  }

  *whenGreenFlagClicked() {
    while (true) {
      null;
      yield;
    }
  }

  *whenGreenFlagClicked2() {}

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.vars.theme) === "light") {
        this.costume = "light";
      }
      if (this.toString(this.vars.theme) === "dark") {
        this.costume = "dark";
      }
      if (this.toString(this.vars.theme) === "the cube") {
        this.costume = "THE CUBE BG";
      }
      if (this.toString(this.vars.theme) === "car battery") {
        this.costume =
          "png-transparent-battery-charger-car-automotive-battery-battery-icon-text-rectangle-automobile-repair-shop";
      }
      yield;
    }
  }
}
