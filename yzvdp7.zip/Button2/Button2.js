/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Button2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("button3-a", "./Button2/costumes/button3-a.svg", {
        x: 44.83099999999999,
        y: 31.180000000000007
      }),
      new Costume("spanish", "./Button2/costumes/spanish.svg", {
        x: 44.83100000000002,
        y: 31.180000000000007
      }),
      new Costume("button3-b", "./Button2/costumes/button3-b.svg", {
        x: 72,
        y: 72
      }),
      new Costume("play", "./Button2/costumes/play.svg", {
        x: 21.83333333333337,
        y: 21.833333333333314
      })
    ];

    this.sounds = [new Sound("pop", "./Button2/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay),
      new Trigger(
        Trigger.BROADCAST,
        { name: "versoins" },
        this.whenIReceiveVersoins
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4)
    ];
  }

  *whenthisspriteclicked() {
    this.broadcast("play");
  }

  *whenGreenFlagClicked() {
    this.visible = true;
  }

  *whenIReceivePlay() {
    this.visible = false;
  }

  *whenIReceiveVersoins() {
    this.visible = false;
  }

  *whenIReceiveMenu() {
    this.visible = true;
  }

  *setSizeToNotMouseHover() {
    while (!(this.size === 100)) {
      this.size -= 5;
      yield;
    }
  }

  *setSizeToMouseHover() {
    while (!(this.size === 130)) {
      this.size += 5;
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        if (this.toString(this.stage.vars.theme) === "dark") {
          this.costume = "dark";
        } else {
          if (this.toString(this.stage.vars.theme) === "light") {
            this.costume = "light";
          }
        }
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "Cubo de trazo dos";
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        this.costume = "button3-a";
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "spanish";
        }
      }
      yield;
    }
  }
}
