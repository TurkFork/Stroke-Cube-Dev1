/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Button3 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("button3-a", "./Button3/costumes/button3-a.svg", {
        x: 44.83099999999999,
        y: 31.180000000000007
      }),
      new Costume("spanish", "./Button3/costumes/spanish.svg", {
        x: 44.831000000000046,
        y: 31.180000000000007
      }),
      new Costume("button3-b", "./Button3/costumes/button3-b.svg", {
        x: 72,
        y: 72
      }),
      new Costume("comment-code", "./Button3/costumes/comment-code.svg", {
        x: 24.5,
        y: 24.5
      })
    ];

    this.sounds = [
      new Sound("pop", "./Button3/sounds/pop.wav"),
      new Sound("Chill", "./Button3/sounds/Chill.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "versoins" },
        this.whenIReceiveVersoins
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenIReceivePlay() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    this.visible = true;
  }

  *whenIReceiveMenu() {
    this.visible = true;
  }

  *whenthisspriteclicked() {
    this.broadcast("versoins");
  }

  *whenIReceiveVersoins() {
    this.visible = false;
  }

  *setSizeToMouseHover() {
    while (!(this.size === 130)) {
      this.size += 5;
      yield;
    }
  }

  *setSizeToNotMouseHover() {
    while (!(this.size === 100)) {
      this.size -= 5;
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "spanish") {
        null;
      } else {
        null;
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        this.costume = "button3-a";
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "spanish";
          if (this.toString(this.stage.vars.theme) === "minimal") {
            this.costume = "comment-code";
          } else {
            0;
          }
        }
      }
      yield;
    }
  }
}
