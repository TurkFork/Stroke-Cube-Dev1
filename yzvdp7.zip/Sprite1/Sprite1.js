/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("light", "./Sprite1/costumes/light.svg", {
        x: 89.44732045227056,
        y: 19.157642164843764
      }),
      new Costume("light2", "./Sprite1/costumes/light2.svg", {
        x: 99.95433126946756,
        y: 25.81146748805108
      }),
      new Costume("dark", "./Sprite1/costumes/dark.svg", {
        x: 85.56948596997302,
        y: 18.178359329687538
      }),
      new Costume(
        "Cubo de trazo dos",
        "./Sprite1/costumes/Cubo de trazo dos.svg",
        { x: 59.119983673095675, y: 15.75 }
      )
    ];

    this.sounds = [
      new Sound("pop", "./Sprite1/sounds/pop.wav"),
      new Sound("lol", "./Sprite1/sounds/lol.mp3"),
      new Sound("00002a05", "./Sprite1/sounds/00002a05.wav"),
      new Sound("00002a2", "./Sprite1/sounds/00002a2.wav"),
      new Sound("00002a3", "./Sprite1/sounds/00002a3.wav"),
      new Sound("00002a4", "./Sprite1/sounds/00002a4.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "play" }, this.whenIReceivePlay),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(
        Trigger.BROADCAST,
        { name: "versoins" },
        this.whenIReceiveVersoins
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu2)
    ];
  }

  *whenIReceivePlay() {
    this.visible = false;
  }

  *whenGreenFlagClicked() {
    this.visible = true;
  }

  *whenIReceiveMenu() {
    this.visible = true;
  }

  *whenIReceiveVersoins() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.toString(this.stage.vars.language) === "english") {
        if (this.toString(this.stage.vars.theme) === "dark") {
          this.costume = "dark";
        } else {
          if (this.toString(this.stage.vars.theme) === "light") {
            this.costume = "light";
          }
        }
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "Cubo de trazo dos";
        }
      }
      if (this.toString(this.stage.vars.theme) === "the cube") {
        this.costume = "dark";
      } else {
        null;
      }
      if (this.toString(this.stage.vars.language) === "english") {
        null;
      } else {
        if (this.toString(this.stage.vars.language) === "spanish") {
          this.costume = "Cubo de trazo dos";
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    this.stage.vars.language = "english";
    this.stage.vars.theme = "light";
  }

  *whenGreenFlagClicked4() {
    this.size = 100;
  }

  *whenIReceiveMenu2() {}
}
