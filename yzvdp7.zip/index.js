import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Sprite1 from "./Sprite1/Sprite1.js";
import Cube from "./Cube/Cube.js";
import Button3 from "./Button3/Button3.js";
import Button2 from "./Button2/Button2.js";
import Versions from "./Versions/Versions.js";
import Button4 from "./Button4/Button4.js";
import Theme from "./Theme/Theme.js";
import Button5 from "./Button5/Button5.js";
import Settingsbckground from "./Settingsbckground/Settingsbckground.js";
import ModsSwitchmodsSwitch2 from "./ModsSwitchmodsSwitch2/ModsSwitchmodsSwitch2.js";
import RandoCode from "./RandoCode/RandoCode.js";
import Button6 from "./Button6/Button6.js";
import Normal from "./Normal/Normal.js";
import NormalText from "./NormalText/NormalText.js";
import Error from "./Error/Error.js";
import Language from "./Language/Language.js";
import DeveloperMode from "./DeveloperMode/DeveloperMode.js";
import DumbCrap from "./DumbCrap/DumbCrap.js";
import DeveloperMode2 from "./DeveloperMode2/DeveloperMode2.js";
import Sprite2 from "./Sprite2/Sprite2.js";
import Sprite3 from "./Sprite3/Sprite3.js";
import AccBckground from "./AccBckground/AccBckground.js";
import Sprite4 from "./Sprite4/Sprite4.js";
import Sprite5 from "./Sprite5/Sprite5.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Sprite1: new Sprite1({
    x: -112,
    y: 129.71898292342698,
    direction: 90.25464623227286,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 7
  }),
  Cube: new Cube({
    x: -134.2337518207411,
    y: -137.0651717830784,
    direction: -8.904543914495918,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 1
  }),
  Button3: new Button3({
    x: -49,
    y: 52,
    direction: 90,
    costumeNumber: 1,
    size: 95.39999999999948,
    visible: true,
    layerOrder: 9
  }),
  Button2: new Button2({
    x: -142.51203421710449,
    y: 52.06582179382032,
    direction: 90,
    costumeNumber: 1,
    size: 95.39999999999826,
    visible: true,
    layerOrder: 8
  }),
  Versions: new Versions({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 2
  }),
  Button4: new Button4({
    x: 177,
    y: -141,
    direction: 90,
    costumeNumber: 1,
    size: 95.39999999999948,
    visible: false,
    layerOrder: 19
  }),
  Theme: new Theme({
    x: -146,
    y: 80,
    direction: 90,
    costumeNumber: 1,
    size: 95.39999999999861,
    visible: false,
    layerOrder: 22
  }),
  Button5: new Button5({
    x: 102,
    y: -142,
    direction: 90,
    costumeNumber: 4,
    size: 95.39999999999833,
    visible: true,
    layerOrder: 15
  }),
  Settingsbckground: new Settingsbckground({
    x: -6,
    y: -2,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 14
  }),
  ModsSwitchmodsSwitch2: new ModsSwitchmodsSwitch2({
    x: -144.36587895030357,
    y: 16.951861036619654,
    direction: 90,
    costumeNumber: 2,
    size: 95.39999999999893,
    visible: false,
    layerOrder: 23
  }),
  RandoCode: new RandoCode({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 3
  }),
  Button6: new Button6({
    x: -49,
    y: -9,
    direction: 90,
    costumeNumber: 5,
    size: 95.39999999999928,
    visible: true,
    layerOrder: 10
  }),
  Normal: new Normal({
    x: -115,
    y: -3,
    direction: 90,
    costumeNumber: 1,
    size: 95.39999999999945,
    visible: false,
    layerOrder: 4
  }),
  NormalText: new NormalText({
    x: 4,
    y: 85,
    direction: 90,
    costumeNumber: 1,
    size: 80,
    visible: false,
    layerOrder: 5
  }),
  Error: new Error({
    x: 2,
    y: 0,
    direction: 90,
    costumeNumber: 2,
    size: 100,
    visible: false,
    layerOrder: 18
  }),
  Language: new Language({
    x: 46,
    y: 97,
    direction: 90,
    costumeNumber: 1,
    size: 95.39999999999968,
    visible: false,
    layerOrder: 20
  }),
  DeveloperMode: new DeveloperMode({
    x: 38.36076371341278,
    y: 19.790284458082795,
    direction: 90,
    costumeNumber: 2,
    size: 95.39999999999897,
    visible: false,
    layerOrder: 21
  }),
  DumbCrap: new DumbCrap({
    x: 0,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 6
  }),
  DeveloperMode2: new DeveloperMode2({
    x: -147.5161045375963,
    y: -36.631788599273364,
    direction: 90,
    costumeNumber: 2,
    size: 95.39999999999878,
    visible: false,
    layerOrder: 24
  }),
  Sprite2: new Sprite2({
    x: 194,
    y: -142,
    direction: 89.89803914790946,
    costumeNumber: 3,
    size: 100,
    visible: true,
    layerOrder: 12
  }),
  Sprite3: new Sprite3({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 2,
    size: 100,
    visible: false,
    layerOrder: 11
  }),
  AccBckground: new AccBckground({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 16
  }),
  Sprite4: new Sprite4({
    x: 194,
    y: 116,
    direction: 90,
    costumeNumber: 3,
    size: 100,
    visible: false,
    layerOrder: 17
  }),
  Sprite5: new Sprite5({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 13
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;
