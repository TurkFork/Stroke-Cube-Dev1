/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Settingsbckground extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("light", "./Settingsbckground/costumes/light.svg", {
        x: 283.9999999999999,
        y: 218.4999999999999
      }),
      new Costume("dark", "./Settingsbckground/costumes/dark.svg", {
        x: 284,
        y: 218.5
      })
    ];

    this.sounds = [new Sound("pop", "./Settingsbckground/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveSettings() {
    this.moveBehind(4);
    this.visible = true;
    this.moveAhead(4);
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.toString(this.stage.vars.theme) === "light") {
        this.costume = "light";
      } else {
        if (this.toString(this.stage.vars.theme) === "dark") {
          this.costume = "dark";
        }
      }
      yield;
    }
  }
}
