/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class ModsSwitchmodsSwitch2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Mods on", "./ModsSwitchmodsSwitch2/costumes/Mods on.svg", {
        x: 71.31867428571431,
        y: 19.50120000000001
      }),
      new Costume("Mods Off", "./ModsSwitchmodsSwitch2/costumes/Mods Off.svg", {
        x: 74.75360011414284,
        y: 20.438758672799963
      })
    ];

    this.sounds = [
      new Sound("pop", "./ModsSwitchmodsSwitch2/sounds/pop.wav"),
      new Sound(
        "Dance Celebrate",
        "./ModsSwitchmodsSwitch2/sounds/Dance Celebrate.wav"
      )
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(
        Trigger.BROADCAST,
        { name: "settings" },
        this.whenIReceiveSettings2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked6),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked7)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.theme = 0;
  }

  *whenIReceiveSettings() {
    this.visible = true;
  }

  *whenGreenFlagClicked3() {
    this.moveAhead();
  }

  *whenthisspriteclicked() {
    if (this.costume.name === "Mods Off") {
      this.stage.vars.mods = "on";
    } else {
      if (this.costume.name === "Mods On") {
        this.stage.vars.mods = "off";
      }
    }
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.mods) === "on") {
        this.costume = "Mods on";
      } else {
        if (this.toString(this.stage.vars.mods) === "off") {
          this.costume = "Mods Off";
        }
      }
      yield;
    }
  }

  *whenIReceiveSettings2() {
    this.visible = true;
  }

  *whenGreenFlagClicked5() {
    this.costume = "Mods Off";
  }

  *whenGreenFlagClicked6() {
    while (true) {
      if (this.touching("mouse")) {
        this.size += 0.2 * (120 - this.size);
      } else {
        this.size += 0.2 * (95 - this.size);
      }
      yield;
    }
  }

  *whenGreenFlagClicked7() {
    this.stage.vars.mods = "off";
  }
}
