/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class AccBckground extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("light", "./AccBckground/costumes/light.svg", {
        x: 283.9999999999999,
        y: 218.4999999999999
      }),
      new Costume("dark", "./AccBckground/costumes/dark.svg", {
        x: 284,
        y: 218.5
      })
    ];

    this.sounds = [new Sound("pop", "./AccBckground/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "acc menu" },
        this.whenIReceiveAccMenu
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveAccMenu() {
    this.moveBehind(4);
    this.visible = true;
    this.moveAhead(6);
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.toString(this.stage.vars.theme) === "light") {
        this.costume = "light";
      } else {
        if (this.toString(this.stage.vars.theme) === "dark") {
          this.costume = "dark";
        }
      }
      yield;
    }
  }
}
