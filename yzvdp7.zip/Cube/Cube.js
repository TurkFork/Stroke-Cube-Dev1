/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Cube extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Cube/costumes/costume1.svg", {
        x: 7.125,
        y: 7.125
      })
    ];

    this.sounds = [new Sound("pop", "./Cube/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Normal" },
        this.whenIReceiveNormal
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Normal" },
        this.whenIReceiveNormal2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "make harder" },
        this.whenIReceiveMakeHarder
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "make harder" },
        this.whenIReceiveMakeHarder2
      ),
      new Trigger(Trigger.BROADCAST, { name: "menu" }, this.whenIReceiveMenu),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME OVER" },
        this.whenIReceiveGameOver
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenIReceiveNormal() {
    this.size = 100;
    this.visible = true;
    this.stage.vars.mode = 6;
    this.stage.vars.cubespeed = 4;
    this.stage.vars.score = 0;
    this.broadcast("makeharderoneasymode");
    this.goto(0, 0);
    while (true) {
      this.move(this.toNumber(this.stage.vars.cubespeed));
      if (this.touching("edge")) {
        this.direction = this.radToScratch(
          Math.atan2(this.mouse.y - this.y, this.mouse.x - this.x)
        );
        /* TODO: Implement motion_ifonedgebounce */ null;
        this.broadcast("make harder");
      } else {
        if (this.touching("mouse")) {
          this.broadcast("GAME OVER");
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveNormal2() {
    this.visible = true;
  }

  *whenIReceiveMakeHarder() {
    this.stage.vars.cubespeed++;
  }

  *whenIReceiveMakeHarder2() {
    this.stage.vars.score++;
  }

  *whenIReceiveMenu() {
    this.visible = false;
  }

  *whenIReceiveGameOver() {
    this.broadcast("menu");
    return;
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.score = 0;
  }
}
